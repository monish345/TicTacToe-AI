from ai import best_move

board = [
    [' ', ' ', ' '],
    [' ', ' ', ' '],
    [' ', ' ', ' ']
]



def print_board():
    for row in board:
        print('|'.join(row))
        print('-' * 5)



def make_move(row, col, player):
    if board[row][col] == ' ':
        board[row][col] = player
        return True
    return False

def check_winner(player):

    for row in board:
        if all(cell == player for cell in row):
            return True

    for col in range(3):
        if all(board[row][col] == player for row in range(3)):
            return True

    if all(board[i][i] == player for i in range(3)):
        return True

    if all(board[i][2 - i] == player for i in range(3)):
        return True

    return False

def board_full():
    for row in board:
        for cell in row:
            if cell == ' ':
                return False
    return True


while True:

    print_board()

    row = int(input("Your row (0-2): "))
    col = int(input("Your col (0-2): "))

    if make_move(row, col, 'X'):

        if check_winner('X'):
            print_board()
            print("You win!")
            break

        if board_full():
            print_board()
            print("Draw!")
            break

        ai_row, ai_col = best_move(board)
        make_move(ai_row, ai_col, 'O')

        if check_winner('O'):
            print_board()
            print("AI wins!")
            break

        if board_full():
            print_board()
            print("Draw!")
            break

    else:
        print("Invalid move")