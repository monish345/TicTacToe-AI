from logging import root
import tkinter as tk
from tkinter import messagebox
from ai import best_move

board = [[' ' for _ in range(3)] for _ in range(3)]
buttons = [[None for _ in range(3)] for _ in range(3)]



def check_winner(player):

    for row in board:
        if all(cell == player for cell in row):
            return True

    for col in range(3):
        if all(board[row][col] == player for row in range(3)):
            return True

    if all(board[i][i] == player for i in range(3)):
        return True

    if all(board[i][2 - i] == player for i in range(3)):
        return True

    return False

def board_full():
    for row in board:
        for cell in row:
            if cell == ' ':
                return False
    return True

def player_move(row, col):

    if board[row][col] == ' ':

        board[row][col] = 'X'
        buttons[row][col]['text'] = 'X'

        if check_winner('X'):
            messagebox.showinfo("Game Over", "You Win!")
            root.quit()

        elif board_full():
            messagebox.showinfo("Game Over", "Draw!")
            root.quit()

        else:
            ai_row, ai_col = best_move(board)
            board[ai_row][ai_col] = 'O'
            buttons[ai_row][ai_col]['text'] = 'O'

            if check_winner('O'):
                messagebox.showinfo("Game Over", "AI Wins!")
                root.quit()

            elif board_full():
                messagebox.showinfo("Game Over", "Draw!")
                root.quit()

root = tk.Tk()
root.title("Tic Tac Toe AI")

for row in range(3):
    for col in range(3):

        button = tk.Button(
            root,
            text=' ',
            width=10,
            height=4,
            command=lambda r=row, c=col: player_move(r, c)
        )

        button.grid(row=row, column=col)
        buttons[row][col] = button

root.mainloop()
