import math


def check_winner(board, player):

    for row in board:
        if all(cell == player for cell in row):
            return True

    for col in range(3):
        if all(board[row][col] == player for row in range(3)):
            return True

    if all(board[i][i] == player for i in range(3)):
        return True

    if all(board[i][2 - i] == player for i in range(3)):
        return True

    return False

def board_full(board):
    for row in board:
        for cell in row:
            if cell == ' ':
                return False
    return True

def minimax(board, depth, is_maximizing):

    if check_winner(board, 'O'):
        return 1

    if check_winner(board, 'X'):
        return -1

    if board_full(board):
        return 0

    if is_maximizing:

        best_score = -math.inf

        for row in range(3):
            for col in range(3):

                if board[row][col] == ' ':
                    board[row][col] = 'O'

                    score = minimax(board, depth + 1, False)

                    board[row][col] = ' '

                    best_score = max(score, best_score)

        return best_score

    else:

        best_score = math.inf

        for row in range(3):
            for col in range(3):

                if board[row][col] == ' ':
                    board[row][col] = 'X'

                    score = minimax(board, depth + 1, True)

                    board[row][col] = ' '

                    best_score = min(score, best_score)

        return best_score
        
def best_move(board):

    best_score = -math.inf
    move = None

    for row in range(3):
        for col in range(3):

            if board[row][col] == ' ':

                board[row][col] = 'O'

                score = minimax(board, 0, False)

                board[row][col] = ' '

                if score > best_score:
                    best_score = score
                    move = (row, col)

    return move
